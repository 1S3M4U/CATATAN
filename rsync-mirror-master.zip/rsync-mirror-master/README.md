rsync-mirror
============

A script that will sync two machines when executed.

See script for documentation.

