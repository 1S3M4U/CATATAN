zip-backup
===========
A simple zip backup script that creates a zip
archive of specified directory.
